package com.quranplayer.app;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;

import java.io.IOException;

/**
 * تطبيق مشغل القرآن الكريم
 * يتيح للمستخدم الاستماع إلى تلاوات القرآن الكريم من الإنترنت
 */
public class MainActivity extends Activity {
    
    // عناصر الواجهة
    private RadioGroup radioGroupReaders;
    private RadioButton radioAlafasy, radioMaiqaly;
    private EditText editSurahNumber;
    private Button buttonPlay, buttonStop;
    private TextView textStatus;
    
    // مشغل الصوت
    private MediaPlayer mediaPlayer;
    
    // روابط القراء
    private static final String URL_ALAFASY = "https://server8.mp3quran.net/afs/";
    private static final String URL_MAIQALY = "https://server8.mp3quran.net/maher/";
    
    // لحفظ الإعدادات
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "QuranPlayerPrefs";
    private static final String KEY_LAST_READER = "lastReader";
    private static final String KEY_LAST_SURAH = "lastSurah";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // تهيئة عناصر الواجهة
        initViews();
        
        // تهيئة SharedPreferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        
        // استرجاع آخر اختيارات المستخدم
        loadLastSettings();
        
        // إعداد أزرار التحكم
        setupButtons();
    }
    
    /**
     * تهيئة عناصر الواجهة
     */
    private void initViews() {
        radioGroupReaders = findViewById(R.id.radioGroupReaders);
        radioAlafasy = findViewById(R.id.radioAlafasy);
        radioMaiqaly = findViewById(R.id.radioMaiqaly);
        editSurahNumber = findViewById(R.id.editSurahNumber);
        buttonPlay = findViewById(R.id.buttonPlay);
        buttonStop = findViewById(R.id.buttonStop);
        textStatus = findViewById(R.id.textStatus);
    }
    
    /**
     * استرجاع آخر إعدادات المستخدم
     */
    private void loadLastSettings() {
        // استرجاع آخر قارئ
        String lastReader = sharedPreferences.getString(KEY_LAST_READER, "alafasy");
        if (lastReader.equals("alafasy")) {
            radioAlafasy.setChecked(true);
        } else {
            radioMaiqaly.setChecked(true);
        }
        
        // استرجاع آخر سورة
        int lastSurah = sharedPreferences.getInt(KEY_LAST_SURAH, 1);
        editSurahNumber.setText(String.valueOf(lastSurah));
    }
    
    /**
     * حفظ إعدادات المستخدم
     */
    private void saveSettings(String reader, int surahNumber) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_LAST_READER, reader);
        editor.putInt(KEY_LAST_SURAH, surahNumber);
        editor.apply();
    }
    
    /**
     * إعداد أزرار التحكم
     */
    private void setupButtons() {
        // زر التشغيل
        buttonPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playSurah();
            }
        });
        
        // زر الإيقاف
        buttonStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlayback();
            }
        });
    }
    
    /**
     * تشغيل السورة المختارة
     */
    private void playSurah() {
        // الحصول على رقم السورة
        String surahText = editSurahNumber.getText().toString().trim();
        
        if (surahText.isEmpty()) {
            Toast.makeText(this, "الرجاء إدخال رقم السورة", Toast.LENGTH_SHORT).show();
            return;
        }
        
        int surahNumber;
        try {
            surahNumber = Integer.parseInt(surahText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "الرجاء إدخال رقم صحيح", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // التحقق من صحة رقم السورة
        if (surahNumber < 1 || surahNumber > 114) {
            Toast.makeText(this, "رقم السورة يجب أن يكون بين 1 و 114", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // تحديد القارئ المختار
        String baseUrl;
        String readerName;
        if (radioAlafasy.isChecked()) {
            baseUrl = URL_ALAFASY;
            readerName = "alafasy";
        } else {
            baseUrl = URL_MAIQALY;
            readerName = "maiqaly";
        }
        
        // بناء رابط التلاوة
        String audioUrl = baseUrl + String.format("%03d", surahNumber) + ".mp3";
        
        // حفظ الإعدادات
        saveSettings(readerName, surahNumber);
        
        // إيقاف أي تشغيل سابق
        stopPlayback();
        
        // تشغيل الصوت
        playAudio(audioUrl);
    }
    
    /**
     * تشغيل الملف الصوتي من الرابط
     */
    private void playAudio(String url) {
        try {
            // تحديث حالة التطبيق
            textStatus.setText("جاري التحميل...");
            buttonPlay.setEnabled(false);
            
            // إنشاء مشغل جديد
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.setDataSource(url);
            
            // الاستعداد للتشغيل بشكل غير متزامن
            mediaPlayer.prepareAsync();
            
            // عند الاستعداد للتشغيل
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.start();
                    textStatus.setText("جاري التشغيل...");
                    buttonPlay.setEnabled(true);
                    buttonStop.setEnabled(true);
                    Toast.makeText(MainActivity.this, "بدأ التشغيل", Toast.LENGTH_SHORT).show();
                }
            });
            
            // عند انتهاء التشغيل
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    textStatus.setText("انتهى التشغيل");
                    buttonStop.setEnabled(false);
                    Toast.makeText(MainActivity.this, "انتهت التلاوة", Toast.LENGTH_SHORT).show();
                }
            });
            
            // في حالة حدوث خطأ
            mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    textStatus.setText("حدث خطأ في التشغيل");
                    buttonPlay.setEnabled(true);
                    buttonStop.setEnabled(false);
                    Toast.makeText(MainActivity.this, "خطأ: تأكد من الاتصال بالإنترنت", Toast.LENGTH_LONG).show();
                    return true;
                }
            });
            
        } catch (IOException e) {
            textStatus.setText("خطأ في الاتصال");
            buttonPlay.setEnabled(true);
            Toast.makeText(this, "خطأ: تأكد من الاتصال بالإنترنت", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
    
    /**
     * إيقاف التشغيل
     */
    private void stopPlayback() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
            textStatus.setText("تم الإيقاف");
            buttonStop.setEnabled(false);
            Toast.makeText(this, "تم إيقاف التشغيل", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // إيقاف التشغيل عند إغلاق التطبيق
        stopPlayback();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        // إيقاف التشغيل عند الخروج من التطبيق
        stopPlayback();
    }
}
